// frontend/src/app/app.component.ts
import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService } from './services/auth.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subscription } from 'rxjs';
import {RouterOutlet} from '@angular/router';
import {CommonModule} from '@angular/common';

interface PetStats {
  level: number;
  xp: number;
  hunger: number;
  happiness: number;
  energy: number;
  health: number;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet],  // <-- ADD RouterOutlet
  template: '<router-outlet></router-outlet>',  // <-- SIMPLE TEMPLATE
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit, OnDestroy {
  username: string | null = null;
  isLoading = false;
  isActionLoading = false;

  petStats: PetStats = {
    level: 1,
    xp: 0,
    hunger: 50,
    happiness: 50,
    energy: 80,
    health: 100
  };

  private apiUrl = 'http://localhost:8080';
  private userSubscription: Subscription | null = null;
  private refreshInterval: any;

  constructor(
    private authService: AuthService,
    private http: HttpClient
  ) {}

  ngOnInit() {
    // Subscribe to user changes
    this.userSubscription = this.authService.currentUser$.subscribe(user => {
      this.username = user?.username || this.authService.getUsername();
      if (this.username) {
        this.loadPetStats();
        this.startAutoRefresh();
      }
    });
  }

  ngOnDestroy() {
    if (this.userSubscription) {
      this.userSubscription.unsubscribe();
    }
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }

  get xpPercentage(): number {
    const xpNeeded = this.getXpNeededForNextLevel();
    return (this.petStats.xp / xpNeeded) * 100;
  }

  get xpNeeded(): number {
    return this.getXpNeededForNextLevel();
  }

  private getXpNeededForNextLevel(): number {
    // Formula: 100 * level (e.g., level 1 needs 100 XP, level 2 needs 200, etc.)
    return this.petStats.level * 100;
  }

  private getAuthHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  loadPetStats() {
    if (!this.username) return;

    this.isLoading = true;
    const headers = this.getAuthHeaders();

    this.http.get<any>(`${this.apiUrl}/pet`, { headers })
      .subscribe({
        next: (data) => {
          this.petStats = {
            level: data.level || 1,
            xp: data.xp || 0,
            hunger: data.hunger || 50,
            happiness: data.happiness || 50,
            energy: data.energy || 80,
            health: data.health || 100
          };
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Failed to load pet stats:', error);
          this.isLoading = false;

          // If unauthorized, logout
          if (error.status === 401) {
            this.authService.logout();
          }
        }
      });
  }

  feedPet() {
    if (this.isActionLoading) return;

    this.isActionLoading = true;
    const headers = this.getAuthHeaders();

    this.http.post<any>(`${this.apiUrl}/pet/feed`, {}, { headers })
      .subscribe({
        next: (response) => {
          console.log('Pet fed:', response.message);
          this.updateStatsAfterAction(response);
          this.isActionLoading = false;
        },
        error: (error) => {
          console.error('Failed to feed pet:', error);
          this.isActionLoading = false;

          if (error.status === 401) {
            this.authService.logout();
          } else if (error.error && error.error.message) {
            alert(error.error.message);
          }
        }
      });
  }

  playWithPet() {
    if (this.isActionLoading) return;

    this.isActionLoading = true;
    const headers = this.getAuthHeaders();

    this.http.post<any>(`${this.apiUrl}/pet/play`, {}, { headers })
      .subscribe({
        next: (response) => {
          console.log('Played with pet:', response.message);
          this.updateStatsAfterAction(response);
          this.isActionLoading = false;
        },
        error: (error) => {
          console.error('Failed to play with pet:', error);
          this.isActionLoading = false;

          if (error.status === 401) {
            this.authService.logout();
          } else if (error.error && error.error.message) {
            alert(error.error.message);
          }
        }
      });
  }

  cleanPet() {
    if (this.isActionLoading) return;

    this.isActionLoading = true;
    const headers = this.getAuthHeaders();

    this.http.post<any>(`${this.apiUrl}/pet/clean`, {}, { headers })
      .subscribe({
        next: (response) => {
          console.log('Pet cleaned:', response.message);
          this.updateStatsAfterAction(response);
          this.isActionLoading = false;
        },
        error: (error) => {
          console.error('Failed to clean pet:', error);
          this.isActionLoading = false;

          if (error.status === 401) {
            this.authService.logout();
          } else if (error.error && error.error.message) {
            alert(error.error.message);
          }
        }
      });
  }

  private updateStatsAfterAction(response: any) {
    // Update stats from response if available
    if (response.pet) {
      this.petStats = {
        level: response.pet.level || this.petStats.level,
        xp: response.pet.xp || this.petStats.xp,
        hunger: response.pet.hunger ?? this.petStats.hunger,
        happiness: response.pet.happiness ?? this.petStats.happiness,
        energy: response.pet.energy ?? this.petStats.energy,
        health: response.pet.health ?? this.petStats.health
      };
    } else {
      // If no updated stats in response, reload from server
      this.loadPetStats();
    }
  }

  private startAutoRefresh() {
    // Refresh pet stats every 30 seconds
    this.refreshInterval = setInterval(() => {
      if (this.username && !this.isLoading && !this.isActionLoading) {
        this.loadPetStats();
      }
    }, 30000);
  }

  logout() {
    this.authService.logout();
  }
}
